package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.HomeworkExercise
import com.example.data.model.Importance
import com.example.data.model.Subject
import com.example.data.model.SubjectWithStats
import com.example.data.repository.HomeworkRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class HomeworkViewModel(
    private val repository: HomeworkRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeworkUiState())
    val uiState: StateFlow<HomeworkUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.ensureDefaultData()
        }

        // Observe subjects and exercises from Room database
        viewModelScope.launch {
            combine(repository.allSubjects, repository.allExercises) { subjects, exercises ->
                val statsMap = exercises.groupBy { it.subjectId }
                val subjectsWithStats = subjects.map { subject ->
                    val list = statsMap[subject.id] ?: emptyList()
                    val incomplete = list.count { !it.isCompleted }
                    SubjectWithStats(
                        subject = subject,
                        incompleteCount = incomplete,
                        totalCount = list.size
                    )
                }

                Pair(subjectsWithStats, exercises)
            }.collect { (subjectsWithStats, exercises) ->
                _uiState.update { current ->
                    val selectedSubj = subjectsWithStats
                        .firstOrNull { it.subject.id == current.selectedSubjectId }
                        ?.subject

                    current.copy(
                        subjectsWithStats = subjectsWithStats,
                        allExercises = exercises,
                        selectedSubject = selectedSubj,
                        isLoading = false
                    )
                }
            }
        }
    }

    fun selectSubject(subjectId: Long) {
        _uiState.update { current ->
            val subj = current.subjectsWithStats.firstOrNull { it.subject.id == subjectId }?.subject
            current.copy(
                selectedSubjectId = subjectId,
                selectedSubject = subj,
                currentScreen = NavigationScreen.SUBJECT_DETAIL
            )
        }
    }

    fun navigateToHome() {
        _uiState.update { it.copy(currentScreen = NavigationScreen.HOME_SUBJECTS, selectedSubjectId = null) }
    }

    fun navigateToAllExercises() {
        _uiState.update { it.copy(currentScreen = NavigationScreen.ALL_EXERCISES, selectedSubjectId = null) }
    }

    fun setSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun setImportanceFilter(importance: Importance?) {
        _uiState.update { it.copy(importanceFilter = importance) }
    }

    fun setStatusFilter(filter: ExerciseFilter) {
        _uiState.update { it.copy(statusFilter = filter) }
    }

    fun toggleDarkMode() {
        _uiState.update { current ->
            val next = when (current.isDarkMode) {
                true -> false
                false -> null
                null -> true
            }
            current.copy(isDarkMode = next)
        }
    }

    fun openAddSubjectDialog() {
        _uiState.update { it.copy(editingSubject = null, isAddSubjectDialogOpen = true) }
    }

    fun openEditSubjectDialog(subject: Subject) {
        _uiState.update { it.copy(editingSubject = subject, isAddSubjectDialogOpen = true) }
    }

    fun closeAddSubjectDialog() {
        _uiState.update { it.copy(editingSubject = null, isAddSubjectDialogOpen = false) }
    }

    fun confirmDeleteSubject(subject: Subject) {
        _uiState.update { it.copy(subjectToDelete = subject) }
    }

    fun dismissDeleteSubject() {
        _uiState.update { it.copy(subjectToDelete = null) }
    }

    fun saveSubject(
        id: Long,
        name: String,
        colorHex: String,
        iconName: String,
        description: String
    ) {
        viewModelScope.launch {
            val cleanName = name.trim()
            if (cleanName.isBlank()) return@launch

            if (id == 0L) {
                repository.insertSubject(
                    Subject(
                        name = cleanName,
                        colorHex = colorHex,
                        iconName = iconName,
                        description = description.trim()
                    )
                )
            } else {
                repository.updateSubject(
                    Subject(
                        id = id,
                        name = cleanName,
                        colorHex = colorHex,
                        iconName = iconName,
                        description = description.trim()
                    )
                )
            }
            closeAddSubjectDialog()
        }
    }

    fun deleteSubject(subject: Subject) {
        viewModelScope.launch {
            repository.deleteSubject(subject)
            _uiState.update { current ->
                if (current.selectedSubjectId == subject.id) {
                    current.copy(
                        selectedSubjectId = null,
                        selectedSubject = null,
                        subjectToDelete = null,
                        currentScreen = NavigationScreen.HOME_SUBJECTS
                    )
                } else {
                    current.copy(subjectToDelete = null)
                }
            }
        }
    }

    fun openAddExerciseDialog(subjectId: Long? = null) {
        _uiState.update { current ->
            current.copy(
                selectedSubjectId = subjectId ?: current.selectedSubjectId,
                editingExercise = null,
                isAddExerciseDialogOpen = true
            )
        }
    }

    fun openEditExerciseDialog(exercise: HomeworkExercise) {
        _uiState.update { it.copy(editingExercise = exercise, isAddExerciseDialogOpen = true) }
    }

    fun closeAddExerciseDialog() {
        _uiState.update { it.copy(editingExercise = null, isAddExerciseDialogOpen = false) }
    }

    fun confirmDeleteExercise(exercise: HomeworkExercise) {
        _uiState.update { it.copy(exerciseToDelete = exercise) }
    }

    fun dismissDeleteExercise() {
        _uiState.update { it.copy(exerciseToDelete = null) }
    }

    fun saveExercise(
        id: Long,
        subjectId: Long,
        title: String,
        description: String,
        dueTimestamp: Long,
        importance: Importance
    ) {
        viewModelScope.launch {
            val cleanTitle = title.trim()
            if (cleanTitle.isBlank()) return@launch

            if (id == 0L) {
                repository.insertExercise(
                    HomeworkExercise(
                        subjectId = subjectId,
                        title = cleanTitle,
                        description = description.trim(),
                        dueTimestamp = dueTimestamp,
                        importance = importance.name,
                        isCompleted = false
                    )
                )
            } else {
                val current = _uiState.value.editingExercise
                val isCompleted = current?.isCompleted ?: false
                val completedTimestamp = current?.completedTimestamp
                repository.updateExercise(
                    HomeworkExercise(
                        id = id,
                        subjectId = subjectId,
                        title = cleanTitle,
                        description = description.trim(),
                        dueTimestamp = dueTimestamp,
                        importance = importance.name,
                        isCompleted = isCompleted,
                        completedTimestamp = completedTimestamp
                    )
                )
            }
            closeAddExerciseDialog()
        }
    }

    fun deleteExercise(exercise: HomeworkExercise) {
        viewModelScope.launch {
            repository.deleteExercise(exercise)
            _uiState.update { it.copy(exerciseToDelete = null) }
        }
    }

    fun toggleExerciseCompletion(exercise: HomeworkExercise) {
        viewModelScope.launch {
            repository.toggleExerciseCompletion(exercise)
        }
    }
}

class HomeworkViewModelFactory(
    private val repository: HomeworkRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(HomeworkViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return HomeworkViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
