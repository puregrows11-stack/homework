package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.PriorityHigh
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.data.model.Importance
import com.example.ui.theme.PriorityHigh as HighColor
import com.example.ui.theme.PriorityLow as LowColor
import com.example.ui.theme.PriorityMedium as MedColor
import com.example.ui.theme.PriorityUrgent as UrgentColor

@Composable
fun PriorityBadge(
    importance: Importance,
    modifier: Modifier = Modifier
) {
    val (color, icon) = when (importance) {
        Importance.LOW -> LowColor to Icons.Default.Flag
        Importance.MEDIUM -> MedColor to Icons.Default.Flag
        Importance.HIGH -> HighColor to Icons.Default.PriorityHigh
        Importance.URGENT -> UrgentColor to Icons.Default.PriorityHigh
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.15f))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = importance.displayName,
                color = color,
                style = MaterialTheme.typography.labelSmall
            )
        }
    }
}
