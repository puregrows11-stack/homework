package com.example.ui.viewmodel

import com.example.data.model.HomeworkExercise
import com.example.data.model.Importance
import com.example.data.model.Subject
import com.example.data.model.SubjectWithStats

enum class ExerciseFilter {
    ALL,
    ACTIVE,
    COMPLETED
}

enum class NavigationScreen {
    HOME_SUBJECTS,
    SUBJECT_DETAIL,
    ALL_EXERCISES
}

data class HomeworkUiState(
    val subjectsWithStats: List<SubjectWithStats> = emptyList(),
    val allExercises: List<HomeworkExercise> = emptyList(),
    val currentScreen: NavigationScreen = NavigationScreen.HOME_SUBJECTS,
    val selectedSubjectId: Long? = null,
    val selectedSubject: Subject? = null,
    val searchQuery: String = "",
    val importanceFilter: Importance? = null,
    val statusFilter: ExerciseFilter = ExerciseFilter.ACTIVE,
    val isDarkMode: Boolean? = true, // default to clean eye-friendly dark mode for study sessions
    val isAddSubjectDialogOpen: Boolean = false,
    val isAddExerciseDialogOpen: Boolean = false,
    val editingSubject: Subject? = null,
    val editingExercise: HomeworkExercise? = null,
    val subjectToDelete: Subject? = null,
    val exerciseToDelete: HomeworkExercise? = null,
    val isLoading: Boolean = true
) {
    val totalPendingCount: Int
        get() = allExercises.count { !it.isCompleted }

    val totalCompletedCount: Int
        get() = allExercises.count { it.isCompleted }

    val totalExercisesCount: Int
        get() = allExercises.size

    val overallCompletionRate: Float
        get() = if (totalExercisesCount == 0) 1f else totalCompletedCount.toFloat() / totalExercisesCount.toFloat()

    val upcomingUrgentTasks: List<HomeworkExercise>
        get() = allExercises
            .filter { !it.isCompleted }
            .sortedWith(
                compareBy<HomeworkExercise> { it.dueTimestamp }
                    .thenByDescending { it.importanceEnum.level }
            )
            .take(3)
}
