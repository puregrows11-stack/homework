package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.HomeworkExercise
import com.example.data.model.Subject
import com.example.ui.components.ExerciseItem
import com.example.ui.components.IconUtils
import com.example.ui.viewmodel.ExerciseFilter
import com.example.ui.viewmodel.HomeworkUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubjectDetailScreen(
    subject: Subject,
    uiState: HomeworkUiState,
    onBack: () -> Unit,
    onAddExercise: (Long) -> Unit,
    onEditExercise: (HomeworkExercise) -> Unit,
    onDeleteExercise: (HomeworkExercise) -> Unit,
    onToggleExercise: (HomeworkExercise) -> Unit,
    onEditSubject: (Subject) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler {
        onBack()
    }

    var currentFilter by remember { mutableStateOf(ExerciseFilter.ACTIVE) }

    val exercisesForSubject = remember(uiState.allExercises, subject.id) {
        uiState.allExercises.filter { it.subjectId == subject.id }
    }

    val incompleteExercises = exercisesForSubject.filter { !it.isCompleted }
    val completedExercises = exercisesForSubject.filter { it.isCompleted }

    val displayedExercises = when (currentFilter) {
        ExerciseFilter.ACTIVE -> incompleteExercises
        ExerciseFilter.COMPLETED -> completedExercises
        ExerciseFilter.ALL -> exercisesForSubject
    }

    val subjectColor = IconUtils.parseColor(subject.colorHex)
    val subjectIcon = IconUtils.getIconByName(subject.iconName)

    val completionRate = if (exercisesForSubject.isEmpty()) 1f
    else completedExercises.size.toFloat() / exercisesForSubject.size.toFloat()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(subjectColor.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = subjectIcon,
                                contentDescription = null,
                                tint = subjectColor,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = subject.name,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to subjects"
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { onEditSubject(subject) },
                        modifier = Modifier.testTag("edit_current_subject_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit subject",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { onAddExercise(subject.id) },
                containerColor = subjectColor,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Add Exercise") },
                modifier = Modifier.testTag("add_exercise_to_subject_fab")
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Subject Banner & Progress Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        if (subject.description.isNotBlank()) {
                            Text(
                                text = subject.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${incompleteExercises.size} remaining • ${completedExercises.size} completed",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "${(completionRate * 100).toInt()}% Done",
                                style = MaterialTheme.typography.labelMedium,
                                color = subjectColor
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        LinearProgressIndicator(
                            progress = { completionRate },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(7.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = subjectColor,
                            trackColor = subjectColor.copy(alpha = 0.15f)
                        )
                    }
                }
            }

            // Filter Chips: Active vs Completed (Archive) vs All
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = currentFilter == ExerciseFilter.ACTIVE,
                        onClick = { currentFilter = ExerciseFilter.ACTIVE },
                        label = { Text("Active (${incompleteExercises.size})") },
                        modifier = Modifier.testTag("filter_active_chip")
                    )

                    FilterChip(
                        selected = currentFilter == ExerciseFilter.COMPLETED,
                        onClick = { currentFilter = ExerciseFilter.COMPLETED },
                        label = { Text("Archived / Completed (${completedExercises.size})") },
                        leadingIcon = {
                            if (currentFilter == ExerciseFilter.COMPLETED) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                        },
                        modifier = Modifier.testTag("filter_completed_chip")
                    )

                    FilterChip(
                        selected = currentFilter == ExerciseFilter.ALL,
                        onClick = { currentFilter = ExerciseFilter.ALL },
                        label = { Text("All (${exercisesForSubject.size})") },
                        modifier = Modifier.testTag("filter_all_chip")
                    )
                }
            }

            // Exercise items
            if (displayedExercises.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = if (currentFilter == ExerciseFilter.COMPLETED) Icons.Default.TaskAlt else Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary.copy(alpha = 0.6f),
                                modifier = Modifier.size(60.dp)
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = when (currentFilter) {
                                    ExerciseFilter.ACTIVE -> if (exercisesForSubject.isEmpty()) "No exercises assigned yet" else "All exercises completed! Great job! 🎉"
                                    ExerciseFilter.COMPLETED -> "No completed exercises in archive yet"
                                    ExerciseFilter.ALL -> "No exercises in this subject"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Use the button below to add a homework assignment",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(displayedExercises, key = { it.id }) { exercise ->
                    ExerciseItem(
                        exercise = exercise,
                        subject = subject,
                        onToggleCompletion = { onToggleExercise(exercise) },
                        onEdit = { onEditExercise(exercise) },
                        onDelete = { onDeleteExercise(exercise) },
                        showSubjectBadge = false
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }
}
