package com.example.ui.components

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.HomeworkExercise
import com.example.data.model.Importance
import com.example.data.model.Subject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddExerciseDialog(
    initialExercise: HomeworkExercise?,
    subjects: List<Subject>,
    preselectedSubjectId: Long?,
    onDismiss: () -> Unit,
    onSave: (id: Long, subjectId: Long, title: String, description: String, dueTimestamp: Long, importance: Importance) -> Unit
) {
    val context = LocalContext.current
    val initialSubjId = initialExercise?.subjectId
        ?: preselectedSubjectId
        ?: subjects.firstOrNull()?.id
        ?: 1L

    var title by remember { mutableStateOf(initialExercise?.title ?: "") }
    var description by remember { mutableStateOf(initialExercise?.description ?: "") }
    var selectedSubjectId by remember { mutableLongStateOf(initialSubjId) }
    var selectedImportance by remember {
        mutableStateOf(initialExercise?.importanceEnum ?: Importance.MEDIUM)
    }

    // Default due timestamp: tomorrow at 18:00
    val defaultDue = remember {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, 1)
        cal.set(Calendar.HOUR_OF_DAY, 18)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        cal.timeInMillis
    }

    var dueTimestamp by remember {
        mutableLongStateOf(initialExercise?.dueTimestamp ?: defaultDue)
    }

    var titleError by remember { mutableStateOf(false) }
    var isSubjectDropdownExpanded by remember { mutableStateOf(false) }

    val selectedSubject = subjects.firstOrNull { it.id == selectedSubjectId }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialExercise == null) "New Assignment / Exercise" else "Edit Exercise",
                style = MaterialTheme.typography.headlineMedium
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Exercise Title
                OutlinedTextField(
                    value = title,
                    onValueChange = {
                        title = it
                        if (it.isNotBlank()) titleError = false
                    },
                    label = { Text("Exercise Title *") },
                    placeholder = { Text("e.g. Problems 1-10 page 45") },
                    singleLine = false,
                    maxLines = 2,
                    isError = titleError,
                    supportingText = {
                        if (titleError) Text("Please enter a title", color = MaterialTheme.colorScheme.error)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("exercise_title_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Subject Selection
                if (subjects.isNotEmpty()) {
                    ExposedDropdownMenuBox(
                        expanded = isSubjectDropdownExpanded,
                        onExpandedChange = { isSubjectDropdownExpanded = it },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = selectedSubject?.name ?: "Select Subject",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Subject") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isSubjectDropdownExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                .testTag("exercise_subject_dropdown")
                        )

                        ExposedDropdownMenu(
                            expanded = isSubjectDropdownExpanded,
                            onDismissRequest = { isSubjectDropdownExpanded = false }
                        ) {
                            subjects.forEach { subject ->
                                val subjColor = IconUtils.parseColor(subject.colorHex)
                                DropdownMenuItem(
                                    text = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier
                                                    .size(12.dp)
                                                    .clip(RoundedCornerShape(3.dp))
                                                    .background(subjColor)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(subject.name)
                                        }
                                    },
                                    onClick = {
                                        selectedSubjectId = subject.id
                                        isSubjectDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // Description
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description & Notes (Optional)") },
                    placeholder = { Text("Formulas to use, instructions, references...") },
                    maxLines = 3,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("exercise_desc_input")
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Importance Level
                Text(
                    text = "Importance Level",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Importance.entries.forEach { importance ->
                        val isSelected = selectedImportance == importance
                        val badgeColor = when (importance) {
                            Importance.LOW -> com.example.ui.theme.PriorityLow
                            Importance.MEDIUM -> com.example.ui.theme.PriorityMedium
                            Importance.HIGH -> com.example.ui.theme.PriorityHigh
                            Importance.URGENT -> com.example.ui.theme.PriorityUrgent
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    if (isSelected) badgeColor.copy(alpha = 0.25f)
                                    else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .clickable { selectedImportance = importance }
                                .then(
                                    if (isSelected) {
                                        Modifier.border(2.dp, badgeColor, RoundedCornerShape(10.dp))
                                    } else Modifier
                                )
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = importance.displayName,
                                style = MaterialTheme.typography.labelMedium,
                                color = if (isSelected) badgeColor else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Due Date & Time Section
                Text(
                    text = "Due Date & Time",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))

                // Quick Date Presets
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val presets = listOf(
                        "Today 21:00" to 0,
                        "Tomorrow 18:00" to 1,
                        "In 3 Days" to 3,
                        "Next Week" to 7
                    )

                    presets.forEach { (label, daysAhead) ->
                        SuggestionChip(
                            onClick = {
                                val cal = Calendar.getInstance()
                                cal.add(Calendar.DAY_OF_YEAR, daysAhead)
                                cal.set(Calendar.HOUR_OF_DAY, if (daysAhead == 0) 21 else 18)
                                cal.set(Calendar.MINUTE, 0)
                                cal.set(Calendar.SECOND, 0)
                                dueTimestamp = cal.timeInMillis
                            },
                            label = { Text(label, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Current Selected Due Date Display & Custom Picker Buttons
                val currentCal = Calendar.getInstance().apply { timeInMillis = dueTimestamp }
                val formattedDate = SimpleDateFormat("EEE, MMM d, yyyy", Locale.getDefault()).format(Date(dueTimestamp))
                val formattedTime = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(dueTimestamp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val year = currentCal.get(Calendar.YEAR)
                            val month = currentCal.get(Calendar.MONTH)
                            val day = currentCal.get(Calendar.DAY_OF_MONTH)

                            DatePickerDialog(context, { _, y, m, d ->
                                currentCal.set(Calendar.YEAR, y)
                                currentCal.set(Calendar.MONTH, m)
                                currentCal.set(Calendar.DAY_OF_MONTH, d)
                                dueTimestamp = currentCal.timeInMillis
                            }, year, month, day).show()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("pick_due_date_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(formattedDate, maxLines = 1)
                    }

                    OutlinedButton(
                        onClick = {
                            val hour = currentCal.get(Calendar.HOUR_OF_DAY)
                            val minute = currentCal.get(Calendar.MINUTE)

                            TimePickerDialog(context, { _, h, min ->
                                currentCal.set(Calendar.HOUR_OF_DAY, h)
                                currentCal.set(Calendar.MINUTE, min)
                                dueTimestamp = currentCal.timeInMillis
                            }, hour, minute, false).show()
                        },
                        modifier = Modifier
                            .weight(0.8f)
                            .testTag("pick_due_time_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccessTime,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(formattedTime, maxLines = 1)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isBlank()) {
                        titleError = true
                    } else {
                        onSave(
                            initialExercise?.id ?: 0L,
                            selectedSubjectId,
                            title,
                            description,
                            dueTimestamp,
                            selectedImportance
                        )
                    }
                },
                modifier = Modifier.testTag("save_exercise_button")
            ) {
                Text(if (initialExercise == null) "Add Exercise" else "Save Changes")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_exercise_button")
            ) {
                Text("Cancel")
            }
        }
    )
}
