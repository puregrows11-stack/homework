package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Translate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

object IconUtils {
    val AVAILABLE_ICONS = listOf(
        "Calculate" to Icons.Default.Calculate,
        "Science" to Icons.Default.Science,
        "Bolt" to Icons.Default.Bolt,
        "Eco" to Icons.Default.Eco,
        "MenuBook" to Icons.Default.MenuBook,
        "Translate" to Icons.Default.Translate,
        "Language" to Icons.Default.Language,
        "Public" to Icons.Default.Public,
        "Terminal" to Icons.Default.Terminal,
        "School" to Icons.Default.School,
        "AutoStories" to Icons.Default.AutoStories,
        "Computer" to Icons.Default.Computer,
        "Palette" to Icons.Default.ColorLens,
        "MusicNote" to Icons.Default.MusicNote,
        "FitnessCenter" to Icons.Default.FitnessCenter
    )

    fun getIconByName(iconName: String): ImageVector {
        return AVAILABLE_ICONS.firstOrNull { it.first.equals(iconName, ignoreCase = true) }?.second
            ?: Icons.Default.School
    }

    fun parseColor(hex: String, fallback: Color = Color(0xFF6366F1)): Color {
        return try {
            val cleanHex = hex.removePrefix("#")
            val colorLong = cleanHex.toLong(16)
            if (cleanHex.length == 6) {
                Color(colorLong or 0x00000000FF000000)
            } else {
                Color(colorLong)
            }
        } catch (_: Exception) {
            fallback
        }
    }
}
