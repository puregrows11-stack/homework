package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Branding & Accent Palette
val PrimaryIndigo = Color(0xFF6366F1)
val PrimaryIndigoDark = Color(0xFF818CF8)
val AccentTeal = Color(0xFF14B8A6)
val AccentTealDark = Color(0xFF2DD4BF)

// Dark Theme Surfaces (Night Review Comfort)
val Slate950 = Color(0xFF0A0F1D) // Deep background
val Slate900 = Color(0xFF0F172A) // Main background
val Slate800 = Color(0xFF1E293B) // Card & surface
val Slate700 = Color(0xFF334155) // Surface variant & borders
val Slate600 = Color(0xFF475569) // Subtle divider
val Slate400 = Color(0xFF94A3B8) // Secondary text
val Slate100 = Color(0xFFF1F5F9) // Primary text in dark

// Light Theme Surfaces
val Slate50 = Color(0xFFF8FAFC)
val Slate200 = Color(0xFFE2E8F0)
val Slate300 = Color(0xFFCBD5E1)

// Priority & Status Colors
val PriorityLow = Color(0xFF10B981) // Emerald
val PriorityMedium = Color(0xFF0EA5E9) // Sky
val PriorityHigh = Color(0xFFF59E0B) // Amber
val PriorityUrgent = Color(0xFFEF4444) // Rose

// Subject Accent Palette
val SubjectColors = listOf(
    "#3B82F6", // Blue
    "#8B5CF6", // Violet
    "#06B6D4", // Cyan
    "#10B981", // Emerald
    "#F59E0B", // Amber
    "#EC4899", // Pink
    "#6366F1", // Indigo
    "#14B8A6", // Teal
    "#F97316", // Orange
    "#84CC16", // Lime
    "#A855F7", // Purple
    "#E11D48"  // Rose
)
