package com.example.ui.components

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DateFormatterUtils {

    fun formatDueDate(timestamp: Long): String {
        val now = Calendar.getInstance()
        val due = Calendar.getInstance().apply { timeInMillis = timestamp }

        val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault())
        val formattedTime = timeFormat.format(Date(timestamp))

        val isToday = now.get(Calendar.YEAR) == due.get(Calendar.YEAR) &&
                now.get(Calendar.DAY_OF_YEAR) == due.get(Calendar.DAY_OF_YEAR)

        val isTomorrow = now.get(Calendar.YEAR) == due.get(Calendar.YEAR) &&
                now.get(Calendar.DAY_OF_YEAR) + 1 == due.get(Calendar.DAY_OF_YEAR)

        val isYesterday = now.get(Calendar.YEAR) == due.get(Calendar.YEAR) &&
                now.get(Calendar.DAY_OF_YEAR) - 1 == due.get(Calendar.DAY_OF_YEAR)

        return when {
            isToday -> "Today • $formattedTime"
            isTomorrow -> "Tomorrow • $formattedTime"
            isYesterday -> "Yesterday • $formattedTime"
            else -> {
                val dateFormat = SimpleDateFormat("MMM d, yyyy • h:mm a", Locale.getDefault())
                dateFormat.format(Date(timestamp))
            }
        }
    }

    fun isOverdue(timestamp: Long, isCompleted: Boolean): Boolean {
        if (isCompleted) return false
        return timestamp < System.currentTimeMillis()
    }
}
