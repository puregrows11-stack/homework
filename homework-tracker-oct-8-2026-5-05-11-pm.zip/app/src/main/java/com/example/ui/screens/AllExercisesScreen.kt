package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.HomeworkExercise
import com.example.data.model.Importance
import com.example.ui.components.ExerciseItem
import com.example.ui.viewmodel.ExerciseFilter
import com.example.ui.viewmodel.HomeworkUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AllExercisesScreen(
    uiState: HomeworkUiState,
    onBack: () -> Unit,
    onAddExercise: () -> Unit,
    onEditExercise: (HomeworkExercise) -> Unit,
    onDeleteExercise: (HomeworkExercise) -> Unit,
    onToggleExercise: (HomeworkExercise) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler {
        onBack()
    }

    var searchQuery by remember { mutableStateOf("") }
    var statusFilter by remember { mutableStateOf(ExerciseFilter.ACTIVE) }
    var selectedImportance by remember { mutableStateOf<Importance?>(null) }

    val subjectMap = remember(uiState.subjectsWithStats) {
        uiState.subjectsWithStats.associate { it.subject.id to it.subject }
    }

    val filteredExercises = remember(
        uiState.allExercises,
        searchQuery,
        statusFilter,
        selectedImportance
    ) {
        uiState.allExercises.filter { exercise ->
            val matchesSearch = searchQuery.isBlank() ||
                    exercise.title.contains(searchQuery, ignoreCase = true) ||
                    exercise.description.contains(searchQuery, ignoreCase = true) ||
                    (subjectMap[exercise.subjectId]?.name?.contains(searchQuery, ignoreCase = true) == true)

            val matchesStatus = when (statusFilter) {
                ExerciseFilter.ACTIVE -> !exercise.isCompleted
                ExerciseFilter.COMPLETED -> exercise.isCompleted
                ExerciseFilter.ALL -> true
            }

            val matchesImportance = selectedImportance == null || exercise.importanceEnum == selectedImportance

            matchesSearch && matchesStatus && matchesImportance
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "All Assignments",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("all_exercises_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to home"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddExercise,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("New Exercise") },
                modifier = Modifier.testTag("all_exercises_add_fab")
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Search field
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search by title, subject or notes...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("all_exercises_search_input")
                )
            }

            // Status Filter Chips
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = statusFilter == ExerciseFilter.ACTIVE,
                        onClick = { statusFilter = ExerciseFilter.ACTIVE },
                        label = { Text("Active (${uiState.totalPendingCount})") },
                        modifier = Modifier.testTag("status_active_chip")
                    )
                    FilterChip(
                        selected = statusFilter == ExerciseFilter.COMPLETED,
                        onClick = { statusFilter = ExerciseFilter.COMPLETED },
                        label = { Text("Completed (${uiState.totalCompletedCount})") },
                        modifier = Modifier.testTag("status_completed_chip")
                    )
                    FilterChip(
                        selected = statusFilter == ExerciseFilter.ALL,
                        onClick = { statusFilter = ExerciseFilter.ALL },
                        label = { Text("All (${uiState.totalExercisesCount})") },
                        modifier = Modifier.testTag("status_all_chip")
                    )
                }
            }

            // Importance Filter Chips
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = selectedImportance == null,
                        onClick = { selectedImportance = null },
                        label = { Text("Any Priority") }
                    )
                    Importance.entries.forEach { imp ->
                        FilterChip(
                            selected = selectedImportance == imp,
                            onClick = {
                                selectedImportance = if (selectedImportance == imp) null else imp
                            },
                            label = { Text(imp.displayName) }
                        )
                    }
                }
            }

            // Exercise items list
            if (filteredExercises.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.TaskAlt,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "No exercises found",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            } else {
                items(filteredExercises, key = { it.id }) { exercise ->
                    ExerciseItem(
                        exercise = exercise,
                        subject = subjectMap[exercise.subjectId],
                        onToggleCompletion = { onToggleExercise(exercise) },
                        onEdit = { onEditExercise(exercise) },
                        onDelete = { onDeleteExercise(exercise) },
                        showSubjectBadge = true
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }
}
