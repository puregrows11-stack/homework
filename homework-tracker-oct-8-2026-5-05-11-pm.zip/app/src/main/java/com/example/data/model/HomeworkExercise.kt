package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "exercises",
    foreignKeys = [
        ForeignKey(
            entity = Subject::class,
            parentColumns = ["id"],
            childColumns = ["subjectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["subjectId"]),
        Index(value = ["dueTimestamp"]),
        Index(value = ["isCompleted"])
    ]
)
data class HomeworkExercise(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val subjectId: Long,
    val title: String,
    val description: String = "",
    val dueTimestamp: Long,
    val importance: String = Importance.MEDIUM.name,
    val isCompleted: Boolean = false,
    val completedTimestamp: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
) {
    val importanceEnum: Importance
        get() = Importance.fromString(importance)
}
