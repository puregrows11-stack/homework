package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.HomeworkDao
import com.example.data.dao.SubjectDao
import com.example.data.model.HomeworkExercise
import com.example.data.model.Importance
import com.example.data.model.Subject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [Subject::class, HomeworkExercise::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun subjectDao(): SubjectDao
    abstract fun homeworkDao(): HomeworkDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "homework_tracker_database"
                )
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.subjectDao(), database.homeworkDao())
                    }
                }
            }
        }

        suspend fun populateInitialData(subjectDao: SubjectDao, homeworkDao: HomeworkDao) {
            if (subjectDao.getSubjectsCount() > 0) return

            val defaultSubjects = listOf(
                Subject(
                    id = 1,
                    name = "Mathematics",
                    colorHex = "#3B82F6", // Royal Blue
                    iconName = "Calculate",
                    description = "Algebra, Geometry, Calculus & Statistics"
                ),
                Subject(
                    id = 2,
                    name = "Physics",
                    colorHex = "#8B5CF6", // Violet / Purple
                    iconName = "Bolt",
                    description = "Mechanics, Electricity, Waves & Optics"
                ),
                Subject(
                    id = 3,
                    name = "Chemistry",
                    colorHex = "#06B6D4", // Cyan
                    iconName = "Science",
                    description = "Organic Chemistry, Reactions & Solutions"
                ),
                Subject(
                    id = 4,
                    name = "Life & Earth Sciences",
                    colorHex = "#10B981", // Emerald Green
                    iconName = "Eco",
                    description = "Biology, Genetics & Geology"
                ),
                Subject(
                    id = 5,
                    name = "Arabic",
                    colorHex = "#F59E0B", // Amber
                    iconName = "MenuBook",
                    description = "Grammar, Literature, Expression & Analysis"
                ),
                Subject(
                    id = 6,
                    name = "French",
                    colorHex = "#EC4899", // Pink
                    iconName = "Translate",
                    description = "Grammar, Reading Comprehension & Essays"
                ),
                Subject(
                    id = 7,
                    name = "English",
                    colorHex = "#6366F1", // Indigo
                    iconName = "Language",
                    description = "Vocabulary, Speaking, Listening & Essays"
                ),
                Subject(
                    id = 8,
                    name = "History & Geography",
                    colorHex = "#D97706", // Dark Amber / Ochre
                    iconName = "Public",
                    description = "Historical Events, Maps & Geopolitics"
                ),
                Subject(
                    id = 9,
                    name = "Computer Science",
                    colorHex = "#0284C7", // Sky Blue
                    iconName = "Terminal",
                    description = "Algorithms, Programming & Databases"
                )
            )

            subjectDao.insertSubjects(defaultSubjects)

            // Seed sample homework exercises
            val now = System.currentTimeMillis()
            val hourMs = 3600_000L
            val dayMs = 24 * hourMs

            val initialExercises = listOf(
                HomeworkExercise(
                    subjectId = 1, // Mathematics
                    title = "Solve Exercise 14 & 18 page 92",
                    description = "Matrix multiplication and determinant calculations. Show all steps.",
                    dueTimestamp = now + (dayMs * 1) + (4 * hourMs),
                    importance = Importance.HIGH.name,
                    isCompleted = false
                ),
                HomeworkExercise(
                    subjectId = 1, // Mathematics
                    title = "Review Derivatives and Integrals Chapter",
                    description = "Prepare summary sheet with all trigonometric formulas.",
                    dueTimestamp = now + (dayMs * 3),
                    importance = Importance.MEDIUM.name,
                    isCompleted = false
                ),
                HomeworkExercise(
                    subjectId = 2, // Physics
                    title = "Harmonic Oscillator Lab Report",
                    description = "Graph damped oscillations and calculate damping coefficient.",
                    dueTimestamp = now + (dayMs * 2),
                    importance = Importance.URGENT.name,
                    isCompleted = false
                ),
                HomeworkExercise(
                    subjectId = 3, // Chemistry
                    title = "Balancing Redox Reactions Worksheet",
                    description = "Complete problems 1 through 10 in acidic medium.",
                    dueTimestamp = now + (dayMs * 1),
                    importance = Importance.MEDIUM.name,
                    isCompleted = false
                ),
                HomeworkExercise(
                    subjectId = 4, // Life & Earth Sciences
                    title = "Cell Division Diagrams (Mitosis vs Meiosis)",
                    description = "Draw and label all 4 phases with clear color-coded chromosomes.",
                    dueTimestamp = now + (dayMs * 4),
                    importance = Importance.LOW.name,
                    isCompleted = false
                ),
                HomeworkExercise(
                    subjectId = 5, // Arabic
                    title = "Poetry Analysis Text Explication",
                    description = "Analyze the metaphors and rhythmic structure of the assigned poem.",
                    dueTimestamp = now + (dayMs * 2) + (2 * hourMs),
                    importance = Importance.MEDIUM.name,
                    isCompleted = false
                ),
                HomeworkExercise(
                    subjectId = 6, // French
                    title = "Essay: Victor Hugo's Romanticism",
                    description = "Write a 500-word critique discussing themes of justice and redemption.",
                    dueTimestamp = now + (dayMs * 5),
                    importance = Importance.HIGH.name,
                    isCompleted = false
                )
            )

            homeworkDao.insertExercises(initialExercises)
        }
    }
}
