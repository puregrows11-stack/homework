package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.HomeworkExercise
import kotlinx.coroutines.flow.Flow

@Dao
interface HomeworkDao {
    @Query("SELECT * FROM exercises ORDER BY isCompleted ASC, dueTimestamp ASC")
    fun getAllExercises(): Flow<List<HomeworkExercise>>

    @Query("SELECT * FROM exercises WHERE subjectId = :subjectId ORDER BY isCompleted ASC, dueTimestamp ASC")
    fun getExercisesForSubject(subjectId: Long): Flow<List<HomeworkExercise>>

    @Query("SELECT * FROM exercises WHERE id = :id LIMIT 1")
    fun getExerciseById(id: Long): Flow<HomeworkExercise?>

    @Query("SELECT COUNT(*) FROM exercises")
    suspend fun getExercisesCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExercise(exercise: HomeworkExercise): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExercises(exercises: List<HomeworkExercise>): List<Long>

    @Update
    suspend fun updateExercise(exercise: HomeworkExercise)

    @Delete
    suspend fun deleteExercise(exercise: HomeworkExercise)

    @Query("DELETE FROM exercises WHERE id = :id")
    suspend fun deleteExerciseById(id: Long)

    @Query("UPDATE exercises SET isCompleted = :isCompleted, completedTimestamp = :completedTimestamp WHERE id = :id")
    suspend fun setCompletionStatus(id: Long, isCompleted: Boolean, completedTimestamp: Long?)
}
