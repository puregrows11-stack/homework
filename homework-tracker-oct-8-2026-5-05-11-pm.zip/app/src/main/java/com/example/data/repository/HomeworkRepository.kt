package com.example.data.repository

import com.example.data.AppDatabase
import com.example.data.dao.HomeworkDao
import com.example.data.dao.SubjectDao
import com.example.data.model.HomeworkExercise
import com.example.data.model.Subject
import kotlinx.coroutines.flow.Flow

class HomeworkRepository(
    private val subjectDao: SubjectDao,
    private val homeworkDao: HomeworkDao
) {
    val allSubjects: Flow<List<Subject>> = subjectDao.getAllSubjects()
    val allExercises: Flow<List<HomeworkExercise>> = homeworkDao.getAllExercises()

    fun getExercisesForSubject(subjectId: Long): Flow<List<HomeworkExercise>> {
        return homeworkDao.getExercisesForSubject(subjectId)
    }

    fun getSubjectById(subjectId: Long): Flow<Subject?> {
        return subjectDao.getSubjectById(subjectId)
    }

    suspend fun insertSubject(subject: Subject): Long {
        return subjectDao.insertSubject(subject)
    }

    suspend fun updateSubject(subject: Subject) {
        subjectDao.updateSubject(subject)
    }

    suspend fun deleteSubject(subject: Subject) {
        subjectDao.deleteSubject(subject)
    }

    suspend fun insertExercise(exercise: HomeworkExercise): Long {
        return homeworkDao.insertExercise(exercise)
    }

    suspend fun updateExercise(exercise: HomeworkExercise) {
        homeworkDao.updateExercise(exercise)
    }

    suspend fun deleteExercise(exercise: HomeworkExercise) {
        homeworkDao.deleteExercise(exercise)
    }

    suspend fun toggleExerciseCompletion(exercise: HomeworkExercise) {
        val newStatus = !exercise.isCompleted
        val completedTimestamp = if (newStatus) System.currentTimeMillis() else null
        homeworkDao.setCompletionStatus(exercise.id, newStatus, completedTimestamp)
    }

    suspend fun ensureDefaultData() {
        if (subjectDao.getSubjectsCount() == 0) {
            AppDatabase.populateInitialData(subjectDao, homeworkDao)
        }
    }
}
