package com.example.data.model

data class SubjectWithStats(
    val subject: Subject,
    val incompleteCount: Int,
    val totalCount: Int
) {
    val completedCount: Int
        get() = (totalCount - incompleteCount).coerceAtLeast(0)

    val completionRate: Float
        get() = if (totalCount == 0) 1f else completedCount.toFloat() / totalCount.toFloat()
}
