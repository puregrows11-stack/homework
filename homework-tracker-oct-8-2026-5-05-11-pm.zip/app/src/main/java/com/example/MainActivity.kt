package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.example.data.AppDatabase
import com.example.data.repository.HomeworkRepository
import com.example.ui.components.AddExerciseDialog
import com.example.ui.components.AddSubjectDialog
import com.example.ui.screens.AllExercisesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SubjectDetailScreen
import com.example.ui.theme.HomeworkTrackerTheme
import com.example.ui.viewmodel.HomeworkViewModel
import com.example.ui.viewmodel.HomeworkViewModelFactory
import com.example.ui.viewmodel.NavigationScreen

class MainActivity : ComponentActivity() {

    private val viewModel: HomeworkViewModel by viewModels {
        val database = AppDatabase.getDatabase(applicationContext, lifecycleScope)
        val repository = HomeworkRepository(database.subjectDao(), database.homeworkDao())
        HomeworkViewModelFactory(repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()
            val systemDark = isSystemInDarkTheme()
            val isDark = uiState.isDarkMode ?: systemDark

            HomeworkTrackerTheme(darkTheme = isDark) {
                HomeworkTrackerApp(
                    viewModel = viewModel
                )
            }
        }
    }
}

@Composable
fun HomeworkTrackerApp(
    viewModel: HomeworkViewModel
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
        when (uiState.currentScreen) {
            NavigationScreen.HOME_SUBJECTS -> {
                HomeScreen(
                    uiState = uiState,
                    onSubjectClick = { subjectId -> viewModel.selectSubject(subjectId) },
                    onEditSubject = { subject -> viewModel.openEditSubjectDialog(subject) },
                    onDeleteSubject = { subject -> viewModel.confirmDeleteSubject(subject) },
                    onAddSubjectClick = { viewModel.openAddSubjectDialog() },
                    onAddExerciseClick = { viewModel.openAddExerciseDialog() },
                    onViewAllExercisesClick = { viewModel.navigateToAllExercises() },
                    onToggleTheme = { viewModel.toggleDarkMode() },
                    modifier = Modifier.padding(innerPadding)
                )
            }

            NavigationScreen.SUBJECT_DETAIL -> {
                val subject = uiState.selectedSubject
                if (subject != null) {
                    SubjectDetailScreen(
                        subject = subject,
                        uiState = uiState,
                        onBack = { viewModel.navigateToHome() },
                        onAddExercise = { subjectId -> viewModel.openAddExerciseDialog(subjectId) },
                        onEditExercise = { exercise -> viewModel.openEditExerciseDialog(exercise) },
                        onDeleteExercise = { exercise -> viewModel.confirmDeleteExercise(exercise) },
                        onToggleExercise = { exercise -> viewModel.toggleExerciseCompletion(exercise) },
                        onEditSubject = { subj -> viewModel.openEditSubjectDialog(subj) },
                        modifier = Modifier.padding(innerPadding)
                    )
                } else {
                    viewModel.navigateToHome()
                }
            }

            NavigationScreen.ALL_EXERCISES -> {
                AllExercisesScreen(
                    uiState = uiState,
                    onBack = { viewModel.navigateToHome() },
                    onAddExercise = { viewModel.openAddExerciseDialog() },
                    onEditExercise = { exercise -> viewModel.openEditExerciseDialog(exercise) },
                    onDeleteExercise = { exercise -> viewModel.confirmDeleteExercise(exercise) },
                    onToggleExercise = { exercise -> viewModel.toggleExerciseCompletion(exercise) },
                    modifier = Modifier.padding(innerPadding)
                )
            }
        }

        // Add/Edit Subject Dialog
        if (uiState.isAddSubjectDialogOpen) {
            AddSubjectDialog(
                initialSubject = uiState.editingSubject,
                onDismiss = { viewModel.closeAddSubjectDialog() },
                onSave = { id, name, colorHex, iconName, desc ->
                    viewModel.saveSubject(id, name, colorHex, iconName, desc)
                }
            )
        }

        // Add/Edit Exercise Dialog
        if (uiState.isAddExerciseDialogOpen) {
            val subjectsList = uiState.subjectsWithStats.map { it.subject }
            AddExerciseDialog(
                initialExercise = uiState.editingExercise,
                subjects = subjectsList,
                preselectedSubjectId = uiState.selectedSubjectId,
                onDismiss = { viewModel.closeAddExerciseDialog() },
                onSave = { id, subjectId, title, desc, dueTime, importance ->
                    viewModel.saveExercise(id, subjectId, title, desc, dueTime, importance)
                }
            )
        }

        // Delete Subject Confirmation Dialog
        uiState.subjectToDelete?.let { subject ->
            AlertDialog(
                onDismissRequest = { viewModel.dismissDeleteSubject() },
                icon = {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error
                    )
                },
                title = { Text("Delete Subject") },
                text = {
                    Text(
                        "Are you sure you want to delete '${subject.name}'? All assigned exercises for this subject will also be permanently deleted."
                    )
                },
                confirmButton = {
                    Button(
                        onClick = { viewModel.deleteSubject(subject) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.error
                        ),
                        modifier = Modifier.testTag("confirm_delete_subject_button")
                    ) {
                        Text("Delete")
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { viewModel.dismissDeleteSubject() },
                        modifier = Modifier.testTag("cancel_delete_subject_button")
                    ) {
                        Text("Cancel")
                    }
                }
            )
        }

        // Delete Exercise Confirmation Dialog
        uiState.exerciseToDelete?.let { exercise ->
            AlertDialog(
                onDismissRequest = { viewModel.dismissDeleteExercise() },
                icon = {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error
                    )
                },
                title = { Text("Delete Exercise") },
                text = {
                    Text("Are you sure you want to delete '${exercise.title}'?")
                },
                confirmButton = {
                    Button(
                        onClick = { viewModel.deleteExercise(exercise) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.error
                        ),
                        modifier = Modifier.testTag("confirm_delete_exercise_button")
                    ) {
                        Text("Delete")
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { viewModel.dismissDeleteExercise() },
                        modifier = Modifier.testTag("cancel_delete_exercise_button")
                    ) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}
